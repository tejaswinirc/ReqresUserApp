# Reqres Users - Android App

This is a basic Android app built in Java that fetches user data from the Reqres API and displays it in a searchable list.

## Features

- Calls API: `https://reqres.in/api/users?page=2`
- Displays user details in a ListView (RecyclerView)
- Includes a search bar to filter users by first name
- Built using Retrofit and RecyclerView

## Screenshots

<img src="screen_recording.png" alt="App Screenshot" width="300"/>

## Getting Started

1. Clone the repository
2. Open in Android Studio
3. Run on emulator or device with internet access

## Dependencies

- Retrofit
- Gson Converter
- RecyclerView

## How to Run

- Open the project in Android Studio
- Ensure your emulator or connected device has internet access
- Hit "Run"

## License

This project is part of an internship assignment for Greendzine Technologies Pvt Ltd.
